import React from 'react'
import './index.scss'
import Logo from './logo.png'

class AppDX extends React.Component {
  constructor(props) {
    super(props);
  }

  render() {
    return (
      <div className="cardDX">
        <div className="card-body">
         <h6 className="note"> {this.props.postDaVisualizzare ? this.props.postDaVisualizzare.title : this.props.msg}</h6>
          </div>

      </div>
    )
  }
}


export default AppDX;
