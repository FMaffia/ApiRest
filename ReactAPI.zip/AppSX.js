import React from 'react'
import './index.scss'
import Logo from './logo.png'
import AppDX from './AppDX';

class AppSX extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      items: [],
      isLoaded: false
    }
  }
  componentDidMount() {
    fetch('https://jsonplaceholder.typicode.com/posts')
      .then(res => res.json())
      .then(json => {
        this.setState({
          isLoaded: true,
          items: json,
        })
      });
  }
  render() {
    var { isLoaded, items } = this.state;
    if (!isLoaded) {
      return <div>Loading...</div>
    } else {
      return <div className="App">
        <ul style={{ listStyle: 'none' }}>
          <h4>Post Presenti</h4>
          {items.map(item => (
            <li key={item.id}>
              <div className="cardSX">
                <div className="card-body">
                  <a href="#" class="card-title littleTitleRed">{item.title}</a>
                  <button className="btn btn-link"
                    onClick={() => this.viewPost(item)}  > Read More</button>
                </div>
              </div>
            </li>
          ))
          }
        </ul>
      </div>
    }
  }
  viewPost(item) {
    let oggetto = { postSelected: item };
    this.props.selezionaPost(oggetto)
  }
}

export default AppSX;
